//Find
		bool RecvDigMotionPacket();
		
///Add
#if defined(GUILD_RANK_SYSTEM)
		bool RecvGuildRanking();
#endif