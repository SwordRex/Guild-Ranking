# Guild Rank System
 
Forked System from Blackdragonx61
https://github.com/blackdragonx61/Metin2-Rank-System