///Add
#if defined(GUILD_RANK_SYSTEM)
#include "PythonGuildRanking.h"
#endif

//Find
		CPythonItem					m_pyItem;
		
///Add
#if defined(GUILD_RANK_SYSTEM)
		CPythonGuildRanking				m_pyGuildRank;
#endif