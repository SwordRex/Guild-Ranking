#Find
	def PartyHealReady(self):
		self.interface.PartyHealReady()
		
#Add
	if app.GUILD_RANK_SYSTEM:
		def BINARY_GUILD_RANK_OPEN(self):
			self.interface.OpenGuildRanking()