//Find
void initfly();

///Add
#if defined(GUILD_RANK_SYSTEM)
void initguildranking();
#endif