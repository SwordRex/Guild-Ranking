//Find
	initfly();
	
///Add
#if defined(GUILD_RANK_SYSTEM)
	initguildranking();
#endif